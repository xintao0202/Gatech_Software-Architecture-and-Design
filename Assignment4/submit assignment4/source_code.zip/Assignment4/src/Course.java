import java.util.*;
public class Course {

	
	private String courseID;
	private String courseTitle;
	public  ArrayList<Course> prereqCourses=new ArrayList<Course>();
	public ArrayList<String> offerTerm=new ArrayList<String>();
	
	
	public Course(String ID, String Title) {
		this.courseID=ID;
		this.courseTitle=Title;
	}
	
	
	public String getID(){
		return this.courseID;
	}
	
	public String getTitile(){
		return this.courseTitle;
	}
	
	/**
	 * @method isOffered checks if the course if in the course catalog read from the courses.csv
	 */
	public boolean isOffered(){
		boolean offered=false;
		CsvReader readCsv=new CsvReader();
		readCsv.addCourseData();
		for (Course c:readCsv.courses){
			if(c.courseID.equals(this.courseID))
				{
				offered=true;
				break;
				}
		}
		return offered;
	}

	/**
	 * @method addPrereq add a course in the list of prerequisites
	 */
	public void addPrereq(Course course) {
		prereqCourses.add(course);
	}
}