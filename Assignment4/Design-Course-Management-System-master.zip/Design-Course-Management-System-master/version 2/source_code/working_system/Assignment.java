/**
 * 
 */

/**
 * @author zhihuixie
 *
 */
public class Assignment {
	int instructorId;
	int courseId;
	int capacity;
	/**
	 * constructor
	 * @param instructorId
	 * @param courseId
	 * @param capacity
	 */
	public Assignment(int instructorId, int courseId, int capacity){
		this.instructorId = instructorId;
		this.courseId = courseId;
		this.capacity = capacity;
	}

}
